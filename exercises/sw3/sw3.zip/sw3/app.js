const searchForm = document.getElementById('search-form')
const cityInput = document.getElementById('city-input')
const hotelsListWrapper = document.getElementById('hotels-list-wrapper')
const loaderIcon = document.getElementById('loader')

function createHotelElement (hotel) {
    const el = document.createElement('li')
    el.innerHTML = '<article class="hotel">' +
        '<div class="hotel-image"><i class="ion-home"></i></div>' +
        '<div class="hotel-data">' +
        '<h1>' + hotel.name + '</h1>' +
        '<address>' + hotel.city + '</address>' +
        '</div></article>'

    return el
}

function printHotels (hotels) {
    loaderIcon.style.display = ''

    for (let index = 0; index < hotels.length; index++) {
        const hotel = hotels[index]
        const hotelElement = createHotelElement(hotel)

        hotelsListWrapper.appendChild(hotelElement)
    }
    cityInput.removeAttribute('disabled')
}

function getHotels (ev) {
    if (ev !== undefined) {
        ev.preventDefault()
    }

    const inputValue = cityInput.value

    hotelsListWrapper.innerHTML = ''
    loaderIcon.style.display = 'block'
    cityInput.setAttribute('disabled', 'disabled')
    get('https://eca-jb-async.herokuapp.com/hotels/' + inputValue, printHotels)
}

getHotels()

searchForm.addEventListener('submit', getHotels)
cityInput.addEventListener('input', debounce(getHotels, 500))
