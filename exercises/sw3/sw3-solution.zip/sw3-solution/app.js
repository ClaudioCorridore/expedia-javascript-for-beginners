const searchForm = document.getElementById('search-form')
const cityInput = document.getElementById('city-input')
const priceOrderOptions = document.getElementById('price-order')
const hotelsListWrapper = document.getElementById('hotels-list-wrapper')
const loaderIcon = document.getElementById('loader')

function createHotelElement (hotel) {
    const el = document.createElement('li')
    el.innerHTML = '<article class="hotel">' +
        '<div class="hotel-image"><i class="ion-home"></i></div>' +
        '<div class="hotel-data">' +
        '<h1>' + hotel.name + '</h1>' +
        '<address>' + hotel.city + '</address>' +
        '<div class="price"><strong>' + hotel.price + '£</strong></div>' +
        '</div></article>'

    return el
}

function printHotels (hotels) {
    loaderIcon.style.display = ''

    for (let index = 0; index < hotels.length; index++) {
        const hotel = hotels[index]
        const hotelElement = createHotelElement(hotel)

        hotelsListWrapper.appendChild(hotelElement)
    }
    cityInput.removeAttribute('disabled')
}

function getHotelDetails (hotelId) {
    return get('https://eca-jb-async.herokuapp.com/hotel/' + hotelId)
}

function getHotelsDetails (hotels) {
    const detailsPromises = []

    for (let index = 0; index < hotels.length; index++) {
        detailsPromises.push(getHotelDetails(hotels[index].id))
    }

    return Promise.all(detailsPromises)
}

let results

function storeResults (hotels) {
    results = hotels

    return results
}

function orderByPrice () {
    hotelsListWrapper.innerHTML = ''

    if (priceOrderOptions.value === 'asc') {
        return printHotels(results.concat().sort(function (a, b) {
            return a.price - b.price
        }))
    }

    if (priceOrderOptions.value === 'desc') {
        return printHotels(results.concat().sort(function (a, b) {
            return b.price - a.price
        }))
    }

    return printHotels(results)
}

function getHotels (ev) {
    if (ev !== undefined) {
        ev.preventDefault()
    }

    const inputValue = cityInput.value

    hotelsListWrapper.innerHTML = ''
    loaderIcon.style.display = 'block'
    cityInput.setAttribute('disabled', 'disabled')
    get('https://eca-jb-async.herokuapp.com/hotels/' + inputValue)
        .then(getHotelsDetails)
        .then(storeResults)
        .then(printHotels)
}

getHotels()

searchForm.addEventListener('submit', getHotels)
cityInput.addEventListener('input', debounce(getHotels, 500))
priceOrderOptions.addEventListener('change', orderByPrice)
