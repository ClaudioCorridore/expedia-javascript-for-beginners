const searchForm = document.getElementById('search-form');
const cityInput = document.getElementById('city-input');
const hotels = document.getElementsByClassName('hotel');


const filterHotels = function(event) {
    event.preventDefault();

    const city = cityInput.value;

    for (var index = 0; index < hotels.length; index++) {
        const hotel = hotels[index];
        const address = hotel.getElementsByTagName('address')[0].innerText;

        if (!address.toLowerCase().includes(city.toLowerCase())) {
            hotel.classList.add('hidden');
        } else {
            hotel.classList.remove('hidden');
        }
    }
}

searchForm.addEventListener('submit', filterHotels);