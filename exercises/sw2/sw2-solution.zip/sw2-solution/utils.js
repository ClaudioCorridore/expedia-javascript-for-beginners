function get (url, cb) {
    return fetch(url)
        .then(function (response) {
            const contentType = response.headers.get('content-type')

            if (contentType && contentType.includes('application/json')) {
                return response.json()
            }

            throw new TypeError('Oops, we haven\'t got JSON!')
        })
        .then(function (json) {
            if (cb !== undefined && cb instanceof Function) {
                return cb(json)
            }

            return json
        })
        .catch(function (error) {
            console.error(error)
        })
}

function debounce (func, wait, immediate) {
    var timeout
    return function () {
        var context = this
        var args = arguments

        var later = function () {
            timeout = null
            if (!immediate) func.apply(context, args)
        }
        var callNow = immediate && !timeout
        clearTimeout(timeout)
        timeout = setTimeout(later, wait)
        if (callNow) func.apply(context, args)
    }
}
