const searchForm = document.getElementById('search-form')
const cityInput = document.getElementById('city-input')
const hotelsListWrapper = document.getElementById('hotels-list-wrapper')
